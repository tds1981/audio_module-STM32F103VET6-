#include "MuzicFunction.h"
#include "SD_spiProg.h"
#include "LEDs.h"
#include "lcd.h"

uint16_t NumberByte=0;
uint32_t OffsetByte=0;
uint32_t SiseFile=0;
uint8_t StopFlag=0;
//uint8_t Volume=1;
uint8_t NumberTrek=0;

//------------- Disk function ----------
uint32_t StartPaticion;
uint8_t SectorPerCluster;
uint16_t RootEntries ;
uint32_t RootStart;

void ReadMBR()
{
		uint8_t temp=CommandReadSector(0);
		uint16_t count=0;
		StartPaticion=0;
			if (temp==0xfe)
				while (count<512)		
				{
					temp=Send_SPI(0xff);
					if ((count>=0x01C6)&&(count<=0x01CA))	StartPaticion|=temp<<(8*(count-0x01C6));
					count++;
				}
				StartPaticion=StartPaticion*0x200;
}

//--------------------------------------------

uint32_t ReadBootSector()
{
	uint16_t ReservedSectors=0;
	uint16_t SectorPerFat=0;
	uint8_t NumberOfFats=0;
	
			ReadMBR();
			uint8_t temp=CommandReadSector(StartPaticion);
			int count=0;
			if (temp==0xfe)
			{		
				count=0;	
				while (count<512)		
				{
					temp=Send_SPI(0xff);
					if (count==0x0D)	SectorPerCluster|=temp;
					if ((count>=0x0E)&&(count<=0x0F))	ReservedSectors|=temp<<(8*(count-0x0E));
					if ((count>=0x16)&&(count<=0x17))	SectorPerFat|=temp<<(8*(count-0x16));
					if (count==0x10)	NumberOfFats|=temp;
					if ((count>=0x11)&&(count<=0x12))	RootEntries|=temp<<(8*(count-0x11));
					count++;
				}	
			Send_SPI(0xff);
			Send_SPI(0xff);	
			}
		RootStart=(ReservedSectors+(SectorPerFat*NumberOfFats))*0x200;
			/*	LCD_Number(ReservedSectors, 0x80, 6 );
			LCD_Number(SectorPerFat, 0xC0, 6 );
			LL_mDelay(5000);
			
			LCD_Number(RootStart, 0x80, 9 );
			LCD_Number(NumberOfFats, 0xC0, 6 );
			LL_mDelay(2000);*/
}
//----------------------------------------
/*struct FileParametrs1
{
	uint32_t FirstClusterFile;
	uint32_t SizeF;
};*/

uint16_t ReadRootAndPlayWav(uint16_t REntries)
{
	uint32_t i=StartPaticion+RootStart;
	uint32_t EndOffSet=i+(32*RootEntries);
	uint16_t ReturnCount=0, CountEntries=0; //chetchic zapisey kataloga
	
//	FileParametrs1 FP;
//	FP.FirstClusterFile=0;
	uint32_t FirstClusterFile=0;
	uint32_t SizeF=0;
	uint8_t NameFile[9]; 
	while (i<EndOffSet)
	{
		uint8_t temp=CommandReadSector(i);
		int count=0;
		if (temp==0xfe)
			{		
				count=0;	
				uint8_t CountByte=0;
				char TypeFile[3];
				while (count<512)		
				{
					temp=Send_SPI(0xff);
					if ((CountByte<0x08)&&(CountEntries>=REntries)&&(ReturnCount==0)) 	NameFile[CountByte]=temp;
					if ((CountByte>=0x08)&&(CountByte<=0x0A))	
												TypeFile[CountByte-0x08]=temp; 
					if ((TypeFile[0]==0x57)&&(TypeFile[1]==0x41)&&(TypeFile[2]==0x56)	//WAV
									&&(CountEntries>=REntries)&&(ReturnCount==0)) 
					{
							if ((CountByte>=0x1A)&&(CountByte<=0x1B))	FirstClusterFile|=temp<<(8*(CountByte-0x1A));
							if ((CountByte>=0x14)&&(CountByte<=0x15))	FirstClusterFile|=temp<<(8*(2+CountByte-0x14));
							if ((CountByte>=0x1C)&&(CountByte<=0x1F))	SizeF|=temp<<(8*(CountByte-0x1C));
							if (CountByte==0x1F) ReturnCount=CountEntries;
					}
									
					if (++CountByte>=32) 
						{
							CountEntries++;
							CountByte=0; 
							TypeFile[0]=0; TypeFile[1]=0; TypeFile[2]=0; 
						}
					count++;
				}	
			Send_SPI(0xff);
			Send_SPI(0xff);	
			}
			i=i+0x200;
			if ((FirstClusterFile!=0)&&(SizeF!=0)) break;
		}
			//LL_mDelay(2000);
		/*	LCD_Number(RootStart, 0x80, 9 );
			LCD_Number(RootEntries, 0xC0, 9 );
			LL_mDelay(3000);
		
			LCD_Number(FirstClusterFile, 0x80, 9 );
			LCD_Number(SectorPerCluster, 0xC0, 9 );
			LL_mDelay(3000);*/
		
		uint32_t BeginFile = RootStart+(32*RootEntries)+(FirstClusterFile-2)*SectorPerCluster*0x200;
				
		NameFile[8]=0; LCD_String(NameFile,0x80);
		LCD_Number(BeginFile, 0xC0, 9 );	
		//LCD_Number(SizeF, 0xC0, 9 );
		
		NewPlayWav(BeginFile, SizeF);
		return ReturnCount; 
}

//  MUZIC FUNCTION !!!!!!!!!!!!

void SelectTrack(uint8_t NumberTrek)
{
	switch (NumberTrek)
		{
			case 1: NewPlayWav(0x01490000, 3473408);  LEDs(2000, 0x01);  break;
			case 2: NewPlayWav(0x00045000, 12034048); LEDs(2000, 0x08);  break; 
			case 3: NewPlayWav(0x01DB2000, 4419584);  LEDs(2000, 0x40);  break;
			case 4: NewPlayWav(0x01861000, 5574656);  LEDs(2000, 0x200);  break;
		}
}	

void StopTimers()
{
	TIM2->CR1 &= ~TIM_CR1_CEN; 
	//TIM1->CR1 &= ~TIM_CR1_CEN; 
	NVIC_DisableIRQ(TIM2_IRQn);
	TIM1->CCR2=0;
	DAC->CR &= ~DAC_CR_EN1;
}

void NewPlayWav(uint32_t Offset, uint32_t SizeFile)
{
	//StopTimers();
	
	uint32_t i0;
	uint8_t temp;
	
	i0=StartPaticion+Offset;
	uint32_t freq=0;
	//------------------------------------
			SD_init();
			temp=CommandReadSector(i0);	
			int count=0;		
			if (temp==0xfe)
			{		
				count=0;	
				while (count<512)		
				{
					temp=Send_SPI(0xff);
					if ((count>=24)&&(count<=27))	
							freq|=temp<<(8*(count-24));
					count++;
				}	
			Send_SPI(0xff);
			Send_SPI(0xff);	
			}
	
		TIM2->PSC=17;	
		uint32_t freq1=4000000/freq;
		TIM2->ARR=freq1;
		OffsetByte=i0+0x200;
		SiseFile=SizeFile;
		NumberByte=0;
		
		TIM1->PSC=2;
		TIM1->ARR=0xff;
		DAC->CR |= DAC_CR_EN1;
			
		TIM2->CR1 |= TIM_CR1_CEN;
		//TIM1->CR1 |= TIM_CR1_CEN;
		TIM2->DIER |= TIM_DIER_UIE;
		NVIC_EnableIRQ (TIM2_IRQn);
}
//-------------------------------------


void StopWavByte()
{
	if (NumberByte!=0) StopFlag=1;
}

void PlayWavInterrapt()
{
	if (NumberByte==0)
	{
		uint8_t temp=CommandReadSector(OffsetByte);
		uint16_t	count=0;
		OffsetByte=OffsetByte+0x200;
		SiseFile=SiseFile-0x200;
	}
	uint8_t buf= Send_SPI(0xff);
	DAC->DHR12RD = buf;
	TIM1->CCR2 = buf;
	NumberByte++;
	if (NumberByte>=512)
	{
		Send_SPI(0xff);
		Send_SPI(0xff);	
		NumberByte=0;
		if (StopFlag)
			{StopTimers(); StopFlag=0;}
		
		if (SiseFile<=0x400) {
												StopTimers(); StopFlag=0; NumberByte=0; 
												if (NumberTrek>=RootEntries) NumberTrek=1; else NumberTrek++;
												}	
	}

}

//*************************************************************************************

void PlayWav1(uint32_t Offset, uint32_t SizeFile)
{
	uint32_t i, i0;
	uint8_t temp;
	TIM1->PSC=2;
	TIM1->ARR=0xff;
	
	i0=StartPaticion+Offset;
	uint32_t freq=0;
	//------------------------------------
		
			temp=SD_cmd(0x51, i0, 0x95);
		
			int count=0;
			do{												//whait datatoken)
				temp=Send_SPI(0xff);
				count++;
			} while ( (temp!=0xfe)&&(count<0x0fff) );		// fe - datatoken
		
			if (temp==0xfe)
			{		
				count=0;	
				while (count<512)		
				{
					temp=Send_SPI(0xff);
					if ((count>=24)&&(count<=27))	freq|=temp<<(8*(count-24));
					count++;
				}	
			Send_SPI(0xff);
			Send_SPI(0xff);	
			}
	
		freq=4000000/freq;
		TIM2->ARR=freq+1;
		TIM2->CR1 |= TIM_CR1_CEN;

	//------------------------------------
	
	for (i=i0; i<SizeFile+i0; i=i+0x200)
	{
			temp=SD_cmd(0x51, i, 0x95);
		
			count=0;
			do{												//whait datatoken)
				temp=Send_SPI(0xff);
				count++;
			} while ( (temp!=0xfe)&&(count<0x0fff) );		// fe - datatoken
		
			if (temp==0xfe)
			{		
				count=0;	
				while (count<512)		
				{
					if (TIM2->CNT==freq)	{TIM1->CCR2 = Send_SPI(0xff); count++;}
				}	
			Send_SPI(0xff);
			Send_SPI(0xff);	
			} 
	} 
}

