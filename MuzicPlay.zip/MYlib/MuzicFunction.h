#include "main.h"

//#define StartPaticion 0xCA00

//extern uint8_t Volume;
extern uint8_t NumberTrek;

void SelectTrack(uint8_t NumberTrek);
void NewPlayWav(uint32_t Offset, uint32_t SizeFile);
void PlayWav1(uint32_t Offset, uint32_t SizeFile);

void PlayWavByte();
void StopWavByte();

uint32_t ReadBootSector();
uint16_t ReadRootAndPlayWav(uint16_t REntries);