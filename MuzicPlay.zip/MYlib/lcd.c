#include "lcd.h"

void LCD_WriteData(uint8_t dt)
{
  e1;
	if(((dt >> 3)&0x01)==1) {d7_set;} else {d7_reset;}
  if(((dt >> 2)&0x01)==1) {d6_set;} else {d6_reset;}
  if(((dt >> 1)&0x01)==1) {d5_set;} else {d5_reset;}
  if((dt&0x01)==1) {d4_set;} else {d4_reset;}
	for(uint16_t i=0; i<10; i++) {    }
	e0;
	for(uint16_t i=0; i<100; i++) {    }
}

void LCD_Command(uint8_t dt)
{
  rs0; // COMMAND
	
  LCD_WriteData(dt>>4);

	LCD_WriteData(dt);
	
	LL_mDelay(100);
}

void LCD_Data(char dt)
{
  rs1; // data

  LCD_WriteData(dt>>4);
    
	LCD_WriteData(dt);
	
	LL_mDelay(50);
}

void LCD_init(void)
{
  LL_mDelay(50);
	rs0;
	LCD_WriteData(0x03);  HAL_Delay(50);
	//LCD_WriteData(0x03);  HAL_Delay(50);
	//LCD_WriteData(0x03);  HAL_Delay(50);

	LCD_Command(0x28);
	LL_mDelay(300);
	LCD_Command(0x28);
	LL_mDelay(300);
	LCD_Command(0x28);
	LL_mDelay(300);
	
	LCD_Command(0x08);
	LL_mDelay(300);
	LCD_Command(0x0F);
	LL_mDelay(300);
	LCD_Command(0x01);
	LCD_Command(0x06);
	LCD_Command(0x0C); 
	//LCD_Command(0x02);
}

void LCD_String(uint8_t* st, uint8_t p)
{
        LCD_Command(0x01);
				LCD_Command(p); //verh
				uint8_t i=0;
        while((st[i]!=0)&&(i<32))
        {
          if (i==16) LCD_Command(0xC0);
					if ((st[i]!=0x0A)&&(st[i]!=0x0D)) LCD_Data(st[i]);
           i++;
        }
}

#define DIG_BASE  10 
//#define MAX_SIZE 6
unsigned char SYMBOLS[DIG_BASE] = {'0','1','2','3','4','5','6','7','8','9'};
void LCD_Number(uint32_t NUM, uint8_t p, uint8_t MAX_SIZE)
{
 // LCD_Command(0x01);
	p = p + MAX_SIZE-1; 
	LCD_Command(p);
	int i, m;
	
	for(i=MAX_SIZE-1; i>=0; --i)
	{
		m = NUM % DIG_BASE; 
		NUM /= DIG_BASE;  
		LCD_Command(p--);
		//if (i==0) {LCD_Data(','); LCD_Command(p--); }
		LCD_Data(SYMBOLS[m]); 
	}
}