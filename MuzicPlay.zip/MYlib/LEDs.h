#include "main.h"
#define Red LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_3);
#define Green LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_1);
#define Blue LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_0);

#define Led_1 LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_7);
#define Led_2 LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_6);
#define Led_3 LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_15);
#define Led_4 LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_11);
#define Led_5 LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_10);
#define Led_6 LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_9);


void resetLeds();
void LEDs(uint32_t d, uint32_t LedStatus);