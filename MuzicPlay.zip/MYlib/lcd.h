#include "main.h"

#define d4_set LL_GPIO_SetOutputPin(GPIOE, LL_GPIO_PIN_4)
#define d5_set LL_GPIO_SetOutputPin(GPIOE, LL_GPIO_PIN_3)
#define d6_set LL_GPIO_SetOutputPin(GPIOE, LL_GPIO_PIN_2)
#define d7_set LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_2)
#define d4_reset LL_GPIO_ResetOutputPin(GPIOE, LL_GPIO_PIN_4)
#define d5_reset LL_GPIO_ResetOutputPin(GPIOE, LL_GPIO_PIN_3)
#define d6_reset LL_GPIO_ResetOutputPin(GPIOE, LL_GPIO_PIN_2)
#define d7_reset LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_2)

/*
#define e1    LL_GPIO_SetOutputPin(GPIOE, LL_GPIO_PIN_0)  
#define e0    LL_GPIO_ResetOutputPin(GPIOE, LL_GPIO_PIN_0) 
#define rs1   LL_GPIO_SetOutputPin(GPIOE, LL_GPIO_PIN_1)
#define rs0   LL_GPIO_ResetOutputPin(GPIOE, LL_GPIO_PIN_1) 
*/

#define e1    LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_12)  
#define e0    LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_12) 
#define rs1   LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_8)
#define rs0   LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_8)


void LCD_init(void);

void LCD_Command(uint8_t dt);
void LCD_Data(char dt);

void LCD_String(uint8_t* st, uint8_t p);
void LCD_Number(uint32_t NUM, uint8_t p, uint8_t MAX_SIZE );