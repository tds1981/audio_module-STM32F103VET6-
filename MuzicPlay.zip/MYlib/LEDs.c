#include "LEDs.h"

void resetLeds()
{
		LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_7);
		LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_6);
		LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_15);
		LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_11);
		LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_10);
		LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_9);
	
		LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_3);
		LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_1);
		LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_0);
}


void LEDs(uint32_t d, uint32_t LedStatus)
{
	resetLeds();
	//uint32_t LedStatus1=LedStatus|0xf0000000;
	for (uint32_t i=0; i<d/6; i++)
	{
		for (uint8_t k=0; k<6; k++)
		{
			uint8_t L = (LedStatus>>(3*k))&(0x07);
			if ((L&0x01)==0x01) LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_3);
			if ((L&0x02)==0x02) LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_1);
			if ((L&0x04)==0x04) LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_0);
			
			switch (k+1)
			{
				case 1: LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_7); break;
				case 2: LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_6);	break;
				case 3: LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_15); break;
				case 4: LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_11); break;
				case 5: LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_10);break;
				case 6: LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_9); break;
			}
			
			//for (uint8_t k=0; k<100; k++) {}
			LL_mDelay(1);
			resetLeds();
		}
	
	}
		
}