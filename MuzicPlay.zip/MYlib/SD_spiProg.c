#include "SD_spiProg.h"
//#include "LEDs.h"

uint8_t Send_SPI(uint8_t DATA)
{
		uint8_t res=0;
		for(uint8_t i=1; i<=8; i++)
		{
			if ((DATA&0x80)==0x80) MOSI_set; //  1
				else MOSI_reset; //  0
			SCK_set;
				DATA=DATA<<1;
			 res=(res<<1);
			 for (uint8_t k=0; k<5; k++) {}	
			 if (MISO_status)   res=res|0x01;		
				 else res=res&0xFE;
			SCK_reset;
			for (uint8_t k=0; k<2; k++) {}	
		}
		return res;
}

uint8_t SD_cmd(uint8_t b0, uint32_t i, uint8_t b5)
{ 
	uint8_t res;
	long int count;
	uint8_t  b1, b2, b3, b4;
	
	b4 = i&0xff;  
	i=i>>8;
	b3 = i&0xff;
	i=i>>8;
	b2 = i&0xff;
	i=i>>8;
	b1 = i&0xff;
	
	Send_SPI(b0);		
	
	Send_SPI(b1);		
	Send_SPI(b2);
	Send_SPI(b3);
	Send_SPI(b4);
	
	Send_SPI(b5);		// CRC
	count=0;
	do {				
		res=Send_SPI(0xFF);
		count=count+1;
	} while ( ((res&0x80)!=0x00)&&(count<0x0fff) );
	return res;
}

uint8_t SD_init()
{
		LL_mDelay(100);
		SS_set;
		MOSI_set;
	
		for (uint8_t i=1; i<80; i++)
		{
			SCK_set;
			for (uint8_t k=0; k<70; k++) {}
			SCK_reset; 
			for (uint8_t k=0; k<25; k++) {}			
		}
		SS_reset;
		
		uint8_t temp;
		temp=SD_cmd (0x40,0,0x95);	//CMD0 = 01 000000 ??????????? ?????
		if (temp!=0x01) return 1;		// bad init
		//Send_SPI(0xff);  
	
		long int count=0;
		do{				// ?????? ??????? CMD1, ? ????? ????? ??????? ?? ???????? ?????? 0?00, ??????? ??????? ? ???, ??? ????? ?????? ? ?????? ???????
			temp=SD_cmd (0x41,0,0x95);	//CMD1 = 01 000001
			//Send_SPI(0xff);
			count=count+1;
		} while ( (temp!=0x00)&&(count<0x0fff) );		//???? 0x01 ?????? R1
	
		if (count>=0x0fff) return 2;
		return 0;
}

//-----------------------------------------------------------------------------------------------------

uint8_t CommandReadSector(uint32_t FirstByteOffset)
{
			uint8_t temp=SD_cmd(0x51, FirstByteOffset, 0x95);
		
			uint16_t c=0;
			do{												//whait datatoken)
				temp=Send_SPI(0xff);
				c++;
			} while ( (temp!=0xfe)&&(c<0x0fff) );		// fe - datatoken
		
			return temp;
}
