#ifndef RINGTON_H_
#define RINGTON_H_
#include "stm32f1xx_hal.h"
#endif 

#define Timer_ARP	  TIM1->ARR 
#define Timer_CCR		TIM1->CCR2
#define Timer_PSC   TIM1->PSC

#define DelayMicro 5000000

extern uint8_t Melody1[7];
extern uint8_t Melody2[22];
extern uint8_t	mel1[68];
extern uint8_t  mel2[33];
extern uint8_t	mel3[92];

void PlayRington(uint8_t *Melody, uint16_t SizeArr); //
void PlayRington1(uint8_t *Melody, uint16_t SizeArr);
void Pik(uint16_t note);
void  DAC_Pisk();