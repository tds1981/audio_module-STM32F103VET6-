#include "main.h"

#define SS_set LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_6)
#define SS_reset LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_6)

#define MOSI_set LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_5)
#define MOSI_reset LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_5)

/*
#define MOSI_set LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_7)
#define MOSI_reset LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_7)
*/
#define SCK_set LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_3)
#define SCK_reset LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_3)
 
#define MISO_status LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_4)

uint8_t Send_SPI(uint8_t DATA);
uint8_t SD_cmd(uint8_t b0, uint32_t i, uint8_t b5);
uint8_t SD_init();

uint8_t CommandReadSector(uint32_t FirstByteOffset);

