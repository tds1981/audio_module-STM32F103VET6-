#include "GenSig.h"
#include "Buttons.h"

uint16_t buf_sin[60]={
11,45,100,177,274,391,526,678,
844,1024,1215,1415,1622,1834,2048,2262,
2474,2681,2881,3072,3252,3418,3570,3705,
3822,3919,3996,4051,4085,4095,4085,4051,
3996,3919,3822,3705,3570,3418,3252,3072,
2881,2681,2474,2262,2048,1834,1622,1415,
1215,1024,844,678,526,391,274,177,
100,45,11,0
};

uint32_t Period=0;
uint32_t Count=0;
//uint32_t Frequency;

void StartGen(uint32_t Frequency)
{
	//DMA1_Channel3->CCR &= ~(1 << DMA_CCR_EN_Pos);
//	TIM5->CR1 &= ~TIM_CR1_CEN;
	
	TIM1->ARR=18000000/Frequency;
	TIM1->CCR1 = TIM1->ARR/2;
	
	Timer->PSC=71;
	Period=(72000000/(4*(Timer->PSC+1)))/Frequency;
	//Period=Frequency*1000/7407;

	Count=0;
	Timer->DIER |= TIM_DIER_UIE;
	EnableIRQ;
	DAC->CR |= DAC_CR_EN1;
	Timer->CR1|= TIM_CR1_CEN;
	DAC->DHR12RD =0xFFF/2;
	
}

void SintGen()
{
/*
	DMA2_Channel3->CPAR = (uint32_t)(&DAC->DHR12RD); 
  DMA2_Channel3->CMAR = (uint32_t)sinus; 
  DMA2_Channel3->CNDTR = 1;
	
	 DMA2_Channel3->CCR = 0 << DMA_CCR_MEM2MEM_Pos 
    | 0x00 << DMA_CCR_PL_Pos 
    | 0x01 << DMA_CCR_MSIZE_Pos 
    | 0x01 << DMA_CCR_PSIZE_Pos  
    | 0 << DMA_CCR_MINC_Pos 
    | 0 << DMA_CCR_PINC_Pos 
    | 1 << DMA_CCR_CIRC_Pos 
    | 1 << DMA_CCR_DIR_Pos;  
	
	DMA2_Channel3->CCR|= 1 << DMA_CCR_EN_Pos; */

	
}

void StopTimer()
{
	DisableIRQ;
	Timer->CR1 &= ~TIM_CR1_CEN; 
	DAC->CR &= ~DAC_CR_EN1;
}

void TimerInterrapt()
{
	//float FazaPeriod=CountPeriod/Period;
	//DAC->DHR12RD =(uint16_t) (0xFFF*FazaPeriod);
	if (RegimSig==1)
		{if (Count<Period/2) DAC->DHR12RD = 0xFFF; else DAC->DHR12RD =0;}
	
	//if (Count==0) {DAC->DHR12RD = 0xFFF; Count=1;}  else {DAC->DHR12RD =0; Count=0;}
	
	if (RegimSig==2) DAC->DHR12RD =(0xFFF/Period)*Count;
	
		if (RegimSig==3)
		{if (Count<Period/2) DAC->DHR12RD =(0xFFF/Period)*Count; else DAC->DHR12RD =0xFFF-((0xFFF/Period)*Count);}

	if (RegimSig==4)	DAC->DHR12RD =buf_sin[60*Count/Period];	
	
	if (++Count>=Period) Count=0;
}