#ifndef RINGTON_H_
#define RINGTON_H_
#include "stm32f1xx_hal.h"
#endif 

#define Timer_ARP	  TIM3->ARR 
#define Timer_CCR		TIM3->CCR1
#define Timer_PSC   TIM3->PSC

#define DelayMicro 5000000

extern uint8_t Melody1[7];
extern uint8_t Melody2[22];
extern uint8_t	mel1[68];
extern uint8_t  mel2[33];
extern uint8_t	mel3[92];

void PlayRington(uint8_t *Melody, uint16_t SizeArr); //
void PlayRington1(uint8_t *Melody, uint16_t SizeArr);
void Pik(uint16_t note);
