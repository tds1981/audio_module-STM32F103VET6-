#include "main.h"

#define Timer_ARR	  TIM3->ARR 
#define Timer_CCR		TIM3->CCR1
#define Timer_PSC   TIM3->PSC

extern uint8_t RegimSig;

int8_t ScanButtons();
void InterraptButtons();
void Zumer(uint16_t note);