#include "Buttons.h"
#include "lcd.h"
#include "GenSig.h"

void Zumer(uint16_t note)
{
	Timer_PSC = 35;	
	Timer_ARR = note;
	Timer_CCR = Timer_ARR/2;
}

int8_t ScanButtons()
{
		LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_4);
		if (LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)&&LL_GPIO_IsOutputPinSet(GPIOC, LL_GPIO_PIN_4)) 
				{	
					Zumer(3822);
					while(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)){} //&&(ButtonControl<200)
					Timer_CCR=0;
					return 1;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)&&LL_GPIO_IsOutputPinSet(GPIOC, LL_GPIO_PIN_4)) 
				{ 
					Zumer(3607);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)){} 
					Timer_CCR=0;
					return 2;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)&&LL_GPIO_IsOutputPinSet(GPIOC, LL_GPIO_PIN_4)) 
				{	
					Zumer(3405);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)){} 
					Timer_CCR=0;
					return 3;
				}		
		LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_4);
		LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_5);
				
		if(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)&&LL_GPIO_IsOutputPinSet(GPIOC, LL_GPIO_PIN_5)) 
				{	
					Zumer(3214);
					while(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)){} //&&(ButtonControl<200)
					Timer_CCR=0;
					return 4;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)&&LL_GPIO_IsOutputPinSet(GPIOC, LL_GPIO_PIN_5)) 
				{ 
					Zumer(3034);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)){} 
					Timer_CCR=0;
					return 5;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)&&LL_GPIO_IsOutputPinSet(GPIOC, LL_GPIO_PIN_5)) 
				{	
					Zumer(2863);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)){} 
					Timer_CCR=0;
					return 6;
				}
				
		LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_5);		
		LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_0);
				
		if(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)&&LL_GPIO_IsOutputPinSet(GPIOB, LL_GPIO_PIN_0)) 
				{	
					Zumer(2863);
					while(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)){} //&&(ButtonControl<200)
					Timer_CCR=0;
					return 7;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)&&LL_GPIO_IsOutputPinSet(GPIOB, LL_GPIO_PIN_0)) 
				{ 
					Zumer(2703);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)){} 
					Timer_CCR=0;
					return 8;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)&&LL_GPIO_IsOutputPinSet(GPIOB, LL_GPIO_PIN_0)) 
				{	
					Zumer(2551);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)){} 
					Timer_CCR=0;
					return 9;
				}
				
		LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_0);				
		LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_1);
				
		if(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)&&LL_GPIO_IsOutputPinSet(GPIOB, LL_GPIO_PIN_1)) 
				{	
					Zumer(2408);
					while(LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_2)){} //&&(ButtonControl<200)
					Timer_CCR=0;
					return 10;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)&&LL_GPIO_IsOutputPinSet(GPIOB, LL_GPIO_PIN_1)) 
				{ 
					Zumer(2273);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_7)){} 
					Timer_CCR=0;
					return 11;
				}
		
		if(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)&&LL_GPIO_IsOutputPinSet(GPIOB, LL_GPIO_PIN_1)) 
				{	
					Zumer(2145);
					while(LL_GPIO_IsInputPinSet(GPIOE, LL_GPIO_PIN_8)){} 
					Timer_CCR=0;
					return 12;
				}
				
		LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_1);		
		return -1;
}
//***************************************************************************************
uint8_t PosicionSimvol=0x89;
char Freq[7];
uint8_t RegimSig=1;
uint32_t F=1000;
void InterraptButtons()
{
	LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_4);
	LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_5);	
	LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_0);	
	LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_1);		
		switch(ScanButtons())
		{
			case 11: PrintSimvol('0', PosicionSimvol++); Freq[PosicionSimvol-0x89]='0'; break;
			case 1: PrintSimvol('1', PosicionSimvol++); Freq[PosicionSimvol-0x89]='1'; break;
			case 2: PrintSimvol('2', PosicionSimvol++); Freq[PosicionSimvol-0x89]='2'; break;
			case 3: PrintSimvol('3', PosicionSimvol++); Freq[PosicionSimvol-0x89]='3'; break;
			case 4: PrintSimvol('4', PosicionSimvol++); Freq[PosicionSimvol-0x89]='4'; break;
			case 5: PrintSimvol('5', PosicionSimvol++); Freq[PosicionSimvol-0x89]='5'; break;
			case 6: PrintSimvol('6', PosicionSimvol++); Freq[PosicionSimvol-0x89]='6'; break;
			case 7: PrintSimvol('7', PosicionSimvol++); Freq[PosicionSimvol-0x89]='7'; break;
			case 8: PrintSimvol('8', PosicionSimvol++); Freq[PosicionSimvol-0x89]='8'; break;
			case 9: PrintSimvol('9', PosicionSimvol++); Freq[PosicionSimvol-0x89]='9'; break;
			case 10: 	
								LCD_String("Frequency", 0x80);
								if (PosicionSimvol!=0x89) F=StrToInt(Freq, PosicionSimvol-0x88);
								LCD_Number(F, 0xC0, 7); 
								StartGen(F); 
								PosicionSimvol=0x89;
								if (++RegimSig>4) RegimSig=1;
								if (RegimSig==1) {LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_7);LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_11);}
								if (RegimSig==2) {LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_6); LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_7);}
								if (RegimSig==3) {LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_15); LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_6);}
								if (RegimSig==4) {LL_GPIO_ResetOutputPin(GPIOD, LL_GPIO_PIN_11); LL_GPIO_SetOutputPin(GPIOD, LL_GPIO_PIN_15);}
							break;
		}
	if (PosicionSimvol>0x8F)	PosicionSimvol=0x89;
	LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_4);
	LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_5);	
	LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_0);	
	LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_1);		
}