#include "main.h"

#define Timer	  TIM2
#define EnableIRQ NVIC_EnableIRQ(TIM2_IRQn)
#define DisableIRQ NVIC_DisableIRQ(TIM2_IRQn)

//extern uint32_t Frequency;
extern uint16_t buf_sin[60];

void StartGen(uint32_t Frequency);
void TimerInterrapt();
void SintGen();
