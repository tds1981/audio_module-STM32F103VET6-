#include "SD.h"

uint8_t Send_SPI(uint8_t dt)
{
	(void) SPI->DR;
  while(!LL_SPI_IsActiveFlag_TXE(SPI)) {}
  LL_SPI_TransmitData8 (SPI, dt);
  while(!LL_SPI_IsActiveFlag_RXNE(SPI)) {}
  return SPI->DR;
}

uint8_t sd_cmd(uint8_t b0, uint32_t i, uint8_t b5)
{ 
	uint8_t res;
	long int count;
	uint8_t  b1, b2, b3, b4;
	
	b4 = i&0xff;  
	i=i>>8;
	b3 = i&0xff;
	i=i>>8;
	b2 = i&0xff;
	i=i>>8;
	b1 = i&0xff;
	
	Send_SPI(b0);		
	
	Send_SPI(b1);		
	Send_SPI(b2);
	Send_SPI(b3);
	Send_SPI(b4);
	
	Send_SPI(b5);		// CRC
	count=0;
	do {				
		res=Send_SPI(0xFF);
		count=count+1;
	} while ( ((res&0x80)!=0x00)&&(count<0x0fff) );
	return res;
}

uint8_t SD_init()
{
	SS_set;
	LL_SPI_Enable(SPI);
	
	for (uint8_t i=0; i<15; i++) 
	{
		 while(!LL_SPI_IsActiveFlag_TXE(SPI)) {}
		 LL_SPI_TransmitData8 (SPI, 0xFF);
	}
	LL_mDelay(1);
	SS_reset;
	
	uint8_t temp;
	temp=sd_cmd (0x40,0,0x95);	//CMD0 = 01 000000 ??????????? ?????
	if (temp!=0x01) return 1;		// bad init
	//Send_SPI(0xff);  
	
	long int count=0;
	do{				// ?????? ??????? CMD1, ? ????? ????? ??????? ?? ???????? ?????? 0?00, ??????? ??????? ? ???, ??? ????? ?????? ? ?????? ???????
		temp=sd_cmd (0x41,0,0x95);	//CMD1 = 01 000001
		//Send_SPI(0xff);
		count=count+1;
	} while ( (temp!=0x00)&&(count<0x0fff) );		//???? 0x01 ?????? R1
	
	if (count>=0x0fff) return 2;
	return 0;
}