#ifndef SD_H_
#define SD_H_
//#include "stm32f1xx_hal.h"
#endif /* SD_H_ */

#include "main.h"

#define SPI SPI3
#define SS_set LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_6)
#define SS_reset LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_6)

uint8_t Send_SPI(uint8_t dt);
uint8_t sd_cmd(uint8_t b0, uint32_t i, uint8_t b5);
uint8_t SD_init();
